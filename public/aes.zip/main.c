// AES usage example
// compile as: gcc main.c aes.h aes.c

#include <stdlib.h>
#include <stdio.h>
#include "aes.h"

int main(int argc, char *argv[])
{
	unsigned char key[KEY_128] = "uber strong key!";
	unsigned char ptext[16] = "Attack at dawn!";
	unsigned char ctext[16];
	unsigned char decptext[16];
	aes_ctx_t *ctx;
	int i;

	init_aes();
	ctx = aes_alloc_ctx(key, sizeof(key));
	if(!ctx) {
		perror("aes_alloc_ctx");
		return EXIT_FAILURE;
	}
	aes_encrypt(ctx, ptext, ctext);
	aes_decrypt(ctx, ctext, decptext);
	i = 16;
	printf("plaintext: %s\nciphertext: ", ptext);
	for(i = 0; i < 16; i++)
		printf("%02x", ctext[i]);
	printf("\ndecrypted ciphertext: %s\n", decptext);

	aes_free_ctx(ctx);
	return EXIT_SUCCESS;
}
